import React from "react";

function AllUsersPage() {
  return (
      <div className="container">
                <h1 className="text-center w-100 my-3">All Users</h1>


        <p>All users list</p>
      </div>
  );
}

export default AllUsersPage;
