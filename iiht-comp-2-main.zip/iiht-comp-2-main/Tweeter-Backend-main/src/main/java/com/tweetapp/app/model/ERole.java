package com.tweetapp.app.model;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
